package com.sushizen.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ==========================================
// 1. DATA LAYER (MODELOS Y REPOSITORIO)
// ==========================================

data class SushiItem(
    val id: String,
    val nameEs: String,
    val nameEn: String,
    val descriptionEs: String,
    val descriptionEn: String,
    val price: Double,
    val emoji: String
)

data class OrderRecord(
    val id: String,
    val items: List<Pair<SushiItem, Int>>,
    val total: Double,
    val timestamp: String
)

class SushiRepository {
    fun getMenu(): Flow<List<SushiItem>> = flow {
        delay(1200) // Simular carga de red
        emit(
            listOf(
                SushiItem("1", "Roll California 🍣", "California Roll 🍣", "Cangrejo, aguacate y pepino", "Crab, avocado, and cucumber", 120.0, "🍣"),
                SushiItem("2", "Nigiri de Salmón 🐟", "Salmon Nigiri 🐟", "Salmón fresco sobre arroz sazonado", "Fresh salmon over seasoned rice", 95.0, "🍣"),
                SushiItem("3", "Roll Dragón Picante 🐉", "Spicy Dragon Roll 🐉", "Anguila, aguacate y salsa spicy", "Eel, avocado, and spicy sauce", 150.0, "🍱"),
                SushiItem("4", "Tempura Mixto 🍤", "Mixed Tempura 🍤", "Camarón y verduras empanizadas", "Shrimp and fried vegetables", 110.0, "🍤")
            )
        )
    }
}

// ==========================================
// 2. STATE & VIEWMODEL
// ==========================================

sealed interface UiState<out T> {
    object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class AppLanguage { ES, EN }

class SushiViewModel : ViewModel() {
    private val repository = SushiRepository()

    private val _menuState = MutableStateFlow<UiState<List<SushiItem>>>(UiState.Loading)
    val menuState: StateFlow<UiState<List<SushiItem>>> = _menuState.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.ES)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    // Carrito actual: id de producto -> cantidad
    private val _cart = MutableStateFlow<Map<String, Int>>(emptyMap())
    val cart: StateFlow<Map<String, Int>> = _cart.asStateFlow()

    // Historial de pedidos ya confirmados
    private val _orderHistory = MutableStateFlow<List<OrderRecord>>(emptyList())
    val orderHistory: StateFlow<List<OrderRecord>> = _orderHistory.asStateFlow()

    init {
        fetchMenu()
    }

    fun fetchMenu() {
        viewModelScope.launch {
            _menuState.value = UiState.Loading
            repository.getMenu()
                .catch { e -> _menuState.value = UiState.Error(e.localizedMessage ?: "Error") }
                .collect { items -> _menuState.value = UiState.Success(items) }
        }
    }

    fun toggleLanguage() {
        _currentLanguage.value = if (_currentLanguage.value == AppLanguage.ES) AppLanguage.EN else AppLanguage.ES
    }

    fun addToCart(itemId: String) {
        val current = _cart.value.toMutableMap()
        current[itemId] = (current[itemId] ?: 0) + 1
        _cart.value = current
    }

    fun removeFromCart(itemId: String) {
        val current = _cart.value.toMutableMap()
        val qty = current[itemId] ?: return
        if (qty <= 1) current.remove(itemId) else current[itemId] = qty - 1
        _cart.value = current
    }

    fun cartTotal(menuItems: List<SushiItem>): Double {
        return _cart.value.entries.sumOf { (id, qty) ->
            (menuItems.find { it.id == id }?.price ?: 0.0) * qty
        }
    }

    fun cartItemCount(): Int = _cart.value.values.sum()

    fun confirmOrder(menuItems: List<SushiItem>) {
        val cartSnapshot = _cart.value
        if (cartSnapshot.isEmpty()) return

        val itemsWithQty = cartSnapshot.mapNotNull { (id, qty) ->
            menuItems.find { it.id == id }?.let { it to qty }
        }
        val total = itemsWithQty.sumOf { it.first.price * it.second }
        val timestamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        val order = OrderRecord(
            id = System.currentTimeMillis().toString(),
            items = itemsWithQty,
            total = total,
            timestamp = timestamp
        )

        _orderHistory.value = listOf(order) + _orderHistory.value
        _cart.value = emptyMap()
    }
}

// ==========================================
// 3. MAIN ACTIVITY & ENTRY POINT
// ==========================================

class MainActivity : ComponentActivity() {
    private val viewModel: SushiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SushiZenApp(viewModel)
            }
        }
    }
}

@Composable
fun SushiZenApp(viewModel: SushiViewModel) {
    val navController = rememberNavController()
    val menuState by viewModel.menuState.collectAsState()
    val language by viewModel.currentLanguage.collectAsState()
    val cart by viewModel.cart.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Inicio") },
                    label = { Text(if (language == AppLanguage.ES) "Inicio" else "Home") },
                    selected = false,
                    onClick = { navController.navigate("welcome") }
                )
                NavigationBarItem(
                    icon = {
                        BadgedBox(badge = {
                            if (cart.values.sum() > 0) {
                                Badge { Text(cart.values.sum().toString()) }
                            }
                        }) {
                            Icon(Icons.Default.RestaurantMenu, contentDescription = "Menú")
                        }
                    },
                    label = { Text(if (language == AppLanguage.ES) "Menú" else "Menu") },
                    selected = false,
                    onClick = { navController.navigate("menu") }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.History, contentDescription = "Ajustes") },
                    label = { Text(if (language == AppLanguage.ES) "Ajustes" else "Settings") },
                    selected = false,
                    onClick = { navController.navigate("history") }
                )
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "welcome",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("welcome") {
                WelcomeScreen(
                    language = language,
                    onNavigateToMenu = { navController.navigate("menu") }
                )
            }
            composable("menu") {
                MenuScreen(
                    menuState = menuState,
                    language = language,
                    cart = cart,
                    onRetry = { viewModel.fetchMenu() },
                    onAdd = { viewModel.addToCart(it) },
                    onRemove = { viewModel.removeFromCart(it) },
                    onConfirmOrder = { items -> viewModel.confirmOrder(items) },
                    cartTotal = { items -> viewModel.cartTotal(items) }
                )
            }
            composable("history") {
                OrderHistoryScreen(
                    currentLanguage = language,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    orderHistory = viewModel.orderHistory.collectAsState().value
                )
            }
        }
    }
}

// ==========================================
// 4. UI SCREENS (PANTALLAS)
// ==========================================

@Composable
fun WelcomeScreen(
    language: AppLanguage,
    onNavigateToMenu: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "🍣 (っ˘ڡ˘ς) 🍱", fontSize = 54.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Sushi Zen",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (language == AppLanguage.ES)
                    "¡El sushi más fresco directo a tu puerta!"
                else
                    "Fresh sushi delivered straight to your door!",
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }

        Button(
            onClick = onNavigateToMenu,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722))
        ) {
            Text(
                text = if (language == AppLanguage.ES) "Ordenar Ahora" else "Order Now",
                fontSize = 18.sp,
                color = Color.White
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    menuState: UiState<List<SushiItem>>,
    language: AppLanguage,
    cart: Map<String, Int>,
    onRetry: () -> Unit,
    onAdd: (String) -> Unit,
    onRemove: (String) -> Unit,
    onConfirmOrder: (List<SushiItem>) -> Unit,
    cartTotal: (List<SushiItem>) -> Double
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (language == AppLanguage.ES) "Menú Sushi Zen" else "Sushi Zen Menu") }
            )
        },
        bottomBar = {
            if (menuState is UiState.Success && cart.isNotEmpty()) {
                val total = cartTotal(menuState.data)
                Surface(shadowElevation = 8.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (language == AppLanguage.ES) "Total" else "Total",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = "$${"%.2f".format(total)} MXN",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                        Button(
                            onClick = { onConfirmOrder(menuState.data) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722))
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (language == AppLanguage.ES) "Confirmar Pedido" else "Confirm Order")
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (menuState) {
                is UiState.Loading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                is UiState.Error -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "❌ Error: ${menuState.message}")
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = onRetry) {
                            Text(if (language == AppLanguage.ES) "Reintentar" else "Retry")
                        }
                    }
                }
                is UiState.Success -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(menuState.data) { item ->
                            SushiCard(
                                item = item,
                                language = language,
                                quantity = cart[item.id] ?: 0,
                                onAdd = { onAdd(item.id) },
                                onRemove = { onRemove(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SushiCard(
    item: SushiItem,
    language: AppLanguage,
    quantity: Int,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = item.emoji, fontSize = 40.sp)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (language == AppLanguage.ES) item.nameEs else item.nameEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = if (language == AppLanguage.ES) item.descriptionEs else item.descriptionEn,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$${item.price} MXN",
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFFF5722)
                )
            }

            if (quantity == 0) {
                Button(onClick = onAdd) {
                    Text(if (language == AppLanguage.ES) "Pedir" else "Add")
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onRemove) {
                        Text("−", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = quantity.toString(),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    IconButton(onClick = onAdd) {
                        Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderHistoryScreen(
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
    orderHistory: List<OrderRecord>
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (currentLanguage == AppLanguage.ES) "Ajustes e Historial" else "Settings & History") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (currentLanguage == AppLanguage.ES) "Idioma / Language" else "Language / Idioma",
                        fontSize = 16.sp
                    )
                    Button(onClick = onToggleLanguage) {
                        Text(if (currentLanguage == AppLanguage.ES) "Español (ES)" else "English (EN)")
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = if (currentLanguage == AppLanguage.ES) "Historial de Pedidos" else "Order History",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (orderHistory.isEmpty()) {
                Text(
                    text = if (currentLanguage == AppLanguage.ES) "No hay pedidos anteriores." else "No previous orders.",
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(orderHistory) { order ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = order.timestamp, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = "$${"%.2f".format(order.total)} MXN",
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFF5722)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                order.items.forEach { (item, qty) ->
                                    Text(
                                        text = "• ${qty}x ${if (currentLanguage == AppLanguage.ES) item.nameEs else item.nameEn}",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
